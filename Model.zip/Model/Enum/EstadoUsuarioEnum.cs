﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Enum
{
    public enum EstadoUsuarioEnum
    {
        Activo = 1,
        Inactivo = 2,
        Suspendido = 3,
        Baneado = 4,
    }
}
