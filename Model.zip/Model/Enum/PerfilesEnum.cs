﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Enum
{
    public enum PerfilesEnum
    {
        Invitado = 1,
        Cliente = 2,
        RepresentanteVentas = 3,
        GerenteVentas = 4,
        Administrador = 5
    }
}
