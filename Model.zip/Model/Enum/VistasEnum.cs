﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Enum
{
    public enum VistasEnum
    {
        GestionarUsuarios = 1,
        GestionarPerfiles = 2,
        GestionarProductos = 3,
    }

}
